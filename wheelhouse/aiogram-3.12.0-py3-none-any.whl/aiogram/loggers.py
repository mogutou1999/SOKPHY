import logging

dispatcher = logging.getLogger("aiogram.dispatcher")
event = logging.getLogger("aiogram.event")
middlewares = logging.getLogger("aiogram.middlewares")
webhook = logging.getLogger("aiogram.webhook")
scene = logging.getLogger("aiogram.scene")
